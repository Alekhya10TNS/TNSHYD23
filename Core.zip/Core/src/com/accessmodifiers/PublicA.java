package com.accessmodifiers;

public class PublicA {
	public void display() {
		System.out.println("TNS Sessions");
		
	}

}
