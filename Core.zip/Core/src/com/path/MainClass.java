package com.path;

public class MainClass {
	int a=10;
	static String b="java";
	int sample1() {
		return 11;
		
		
	}
static String sample2() {
	return "python";
	
}
public static void main(String[] args) {
	MainClass m1=new MainClass();
	System.out.println(m1.a);
	System.out.println(m1.sample1());
	System.out.println(MainClass.b);
	System.out.println(MainClass.sample2());
	
}
}
