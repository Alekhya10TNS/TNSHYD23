package com.path;

public class Important {
	public static void main(String[] args) {
		Normal n1=new Normal();
		System.out.println(n1.batsman);
		n1.display1();
		System.out.println(Normal.bowler);
		System.out.println(Normal.display2());
		
		
	}

}
