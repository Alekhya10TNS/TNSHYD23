package com.path;

public class Normal {
	String batsman="Virat Kohli";
	static String bowler="Siraj";
	void display1() {
		System.out.println("K.L.Rahul");
		
	}
	static String display2() {
		
		return "Bumrah";
		
			
	}

}
