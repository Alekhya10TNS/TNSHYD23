package com.accessmodifiers;

public class PrivateMain {
	public static void main(String[] args) {
		PrivateA a1=new PrivateA();
		
		
	}

}
