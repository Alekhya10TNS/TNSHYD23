/**
 * 
 */
/**
 * 
 */
module Core {
}